const mongoose = require('mongoose');

const claimSchema = new mongoose.Schema({
  claimId: { type: String, required: true, unique: true },
  reason: { type: String, required: true },
  customReason: { type: String },
  explanation: { type: String, required: true },
  
  location: {
    street: { type: String, required: true },
    city: { type: String, required: true },
    state: { type: String, required: true },
    pincode: { type: Number, required: true },
  },

  photos: [{ type: String }],
  policeReport: { type: String },

  status: { type: String, default: 'OPEN' }, // OPEN, APPROVED, REJECTED
  rejectionReason: { type: String },

  adminFinalStatus: { type: String, default: 'PENDING' }, // PENDING, ADMIN_APPROVED, ADMIN_REJECTED
  adminRejectionReason: { type: String },

  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Claim', claimSchema);
