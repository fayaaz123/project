// server.js
const express = require('express');
const mongoose = require('mongoose');


require('dotenv').config();
const claimRoutes = require('./router/claimRoutes.js');

const app = express();
const cors = require('cors');
app.use(cors()); // ✅ Enable CORS for frontend communication
// Middleware
app.use(express.json());
app.use('/uploads', express.static('uploads')); // serve uploaded files
app.use('/api/claims', claimRoutes); // Apply claimRoutes as middleware

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ MongoDB Connected'))
  .catch((err) => console.error('❌ MongoDB Error:', err));

// Base route
app.get('/', (req, res) => {
  res.send('API is running...');
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
